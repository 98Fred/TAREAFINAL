<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class productoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'producto' =>$this->faker->randomElement($array = array ('samsung','iphone', 'hawei')),
            'precio' => $this->faker->numerify('#####.##'),
        ];
    }
}
