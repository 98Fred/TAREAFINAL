<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class postFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     * 
     */

    public function definition()
    {
        return [

            'dni' => $this->faker->unique()->numerify('####-####-#####'),
            'nombre' => $this->faker->firstName($gender = null).' '.$this->faker->firstName($gender = null),
            'apellido' => $this->faker -> lastname().' '. $this->faker->lastname(),
            'ciudad' => $this->faker->city(),
            'telefono'  => $this->faker->randomElement([8,9]).$this->faker->unique()->numerify('#######'),
            'post' => $this->faker->randomElement($array = array ('digital','fisico')),
        ];
    }
}
